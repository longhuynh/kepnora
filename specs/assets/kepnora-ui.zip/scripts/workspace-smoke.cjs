const { chromium } = require('playwright');
const assert = require('node:assert/strict');
(async () => {
  const browser = await chromium.launch();
  for (const [width, height] of [[320,568],[390,844],[440,956]]) {
    const page = await browser.newPage({ viewport: { width, height } });
    const errors = [];
    page.on('pageerror', e => errors.push(e.message));
    await page.goto('http://localhost:8081');
    await page.getByRole('button',{name:'Get Started',exact:true}).click();
    await page.getByText('Explore demo without signing in',{exact:true}).click();
    await page.getByRole('button',{name:'Create Workspace',exact:true}).click();
    await page.getByText('Enter a workspace name.',{exact:true}).waitFor();
    await page.getByLabel('Workspace Name',{exact:true}).fill('Lake House');
    await page.getByRole('radio',{name:'Vacation Home',exact:true}).click();
    assert(await page.getByRole('radio',{name:'Vacation Home',exact:true}).isChecked());
    await page.getByLabel('Address (Optional)',{exact:true}).fill('123 Lake Road');
    if(width===390) { await page.getByRole('heading',{name:'Create Workspace',exact:true}).scrollIntoViewIfNeeded(); await page.screenshot({path:'previews/create-workspace.png'}); }
    assert(await page.evaluate(()=>document.documentElement.scrollWidth <= innerWidth));
    await page.getByRole('button',{name:'Create Workspace',exact:true}).click();
    await page.getByText('Skip for Now',{exact:true}).click();
    await page.getByText('Skip Asset',{exact:true}).click();
    await page.getByRole('button',{name:'Select workspace',exact:true}).getByText('Lake House',{exact:true}).waitFor();
    await page.getByRole('button',{name:'Profile',exact:true}).click();
    await page.getByText('Workspaces',{exact:true}).click();
    await page.getByText('Lake House\nVacation Home\n123 Lake Road',{exact:true}).waitFor();
    assert.deepEqual(errors,[]);
    await page.reload();
    await page.getByRole('button',{name:'Get Started',exact:true}).click();
    await page.getByText('Explore demo without signing in',{exact:true}).click();
    await page.getByText('Skip for now',{exact:true}).click();
    await page.getByRole('button',{name:'Select workspace',exact:true}).waitFor();
    await page.close();
    console.log(`PASS workspace creation, validation, selection, settings, skip at ${width}x${height}`);
  }
  await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
