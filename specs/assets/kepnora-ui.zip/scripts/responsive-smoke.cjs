const { chromium } = require('playwright');
const assert = require('node:assert/strict');
(async () => {
  const browser = await chromium.launch();
  for (const [width, height] of [[320,568],[375,667],[390,844],[440,956],[768,1024],[844,390]]) {
    const page = await browser.newPage({ viewport: { width, height } });
    const errors = [];
    page.on('pageerror', e => errors.push(e.message));
    await page.goto('http://localhost:8081');
    for (const name of ['Welcome','SignIn','CreateAccount']) {
      if(name === 'SignIn') await page.getByRole('button',{name:'Sign In',exact:true}).click();
      if(name === 'CreateAccount') await page.getByText('Sign Up',{exact:true}).click();
      const action = page.getByRole('button',{ name: name === 'Welcome' ? 'Get Started' : name === 'SignIn' ? 'Sign In' : 'Create Account', exact: true });
      await action.scrollIntoViewIfNeeded();
      const box = await action.boundingBox();
      assert(box && box.x >= 0 && box.x + box.width <= width + 1 && box.y >= 0 && box.y + box.height <= height + 1, `${name} button clipped at ${width}x${height}`);
      assert(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), 'Horizontal overflow');
      if(name !== 'Welcome') await page.getByText('Explore demo without signing in',{exact:true}).scrollIntoViewIfNeeded();
      if(width === 440 && name === 'CreateAccount') { await page.getByRole('button',{name:'Back to welcome',exact:true}).scrollIntoViewIfNeeded(); await page.screenshot({path:'previews/responsive-create-account.png'}); }
    }
    assert.deepEqual(errors, []);
    await page.close();
    console.log(`PASS ${width}x${height}: all entry screens and actions reachable, no horizontal overflow.`);
  }
  await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
