const { chromium } = require('playwright');
const assert = require('node:assert/strict');
(async()=>{
 const browser=await chromium.launch();
 for(const [width,height] of [[320,568],[390,844],[440,956]]) {
  const page=await browser.newPage({viewport:{width,height}});
  const errors=[]; page.on('pageerror',e=>errors.push(e.message));
  await page.goto('http://localhost:8081');
  await page.getByRole('button',{name:'Get Started',exact:true}).click();
  await page.getByText('Explore demo without signing in',{exact:true}).click();
  await page.getByLabel('Workspace Name',{exact:true}).fill('My Home');
  await page.getByRole('button',{name:'Create Workspace',exact:true}).click();
  await page.getByRole('button',{name:'Skip for Now',exact:true}).click();
  await page.getByRole('heading',{name:'Add Your First Asset',exact:true}).waitFor();
  if(width===390){await page.waitForLoadState('networkidle');await page.screenshot({path:'previews/asset-onboarding.png'});}
  assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
  await page.getByRole('button',{name:'Add Asset',exact:true}).click();
  await page.getByText('Choose an asset type above to get started.',{exact:true}).waitFor();
  for(const name of ['Home','HVAC','Appliance','Other Asset']) {
   await page.getByRole('button',{name,exact:true}).click();
   await page.getByLabel('Asset Name',{exact:true}).waitFor();
   await page.getByRole('button',{name:'Close asset form',exact:true}).click();
  }
  await page.getByRole('button',{name:'Vehicle',exact:true}).click();
  await page.getByRole('button',{name:'Save Asset',exact:true}).click();
  await page.getByText('Enter an asset name.',{exact:true}).waitFor();
  await page.getByLabel('Asset Name',{exact:true}).fill('Family SUV');
  await page.getByLabel('Model or Details (Optional)',{exact:true}).fill('Honda CR-V');
  await page.getByRole('button',{name:'Save Asset',exact:true}).click();
  await page.getByText('Family SUV added to My Home.',{exact:true}).waitFor();
  await page.getByRole('button',{name:'Assets',exact:true}).click();
  await page.getByPlaceholder('Search assets...').fill('Family SUV');
  await page.getByText('Family SUV',{exact:true}).waitFor();
  assert.deepEqual(errors,[]);
  await page.close(); console.log(`PASS asset categories, validation, creation, search at ${width}x${height}`);
 }
 await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
