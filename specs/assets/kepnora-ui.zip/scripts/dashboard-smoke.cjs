const { chromium } = require('playwright');
const assert = require('node:assert/strict');
(async()=>{
 const browser=await chromium.launch();
 for(const [width,height] of [[320,568],[390,844],[440,956]]) {
  const page=await browser.newPage({viewport:{width,height}}); const errors=[];
  page.on('pageerror',e=>errors.push(e.message));
  await page.goto('http://localhost:8081');
  await page.getByRole('button',{name:'Sign In',exact:true}).click();
  await page.getByText('Explore demo without signing in',{exact:true}).click();
  await page.getByRole('button',{name:'Select workspace',exact:true}).waitFor();
  await page.waitForLoadState('networkidle');
  if(width===390) await page.screenshot({path:'previews/new-dashboard.png'});
  assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
  await page.getByRole('button',{name:'Properties',exact:true}).click();
  await page.getByText('10615 Thistle Flower Dr\nCypress, TX 77433',{exact:true}).waitFor();
  await page.getByRole('button',{name:'Home',exact:true}).click();
  await page.getByRole('button',{name:'Add Vehicle',exact:true}).click();
  await page.getByLabel('Asset Name',{exact:true}).fill('Family Van');
  await page.getByRole('button',{name:'Save Asset',exact:true}).click();
  await page.getByText('Family Van added.',{exact:true}).waitFor();
  await page.getByRole('button',{name:'Add Document',exact:true}).click();
  await page.getByLabel('Document title',{exact:true}).fill('Home Insurance');
  await page.getByRole('button',{name:'Save document record',exact:true}).click();
  await page.getByText('Home Insurance',{exact:true}).waitFor();
  await page.getByRole('button',{name:'Home',exact:true}).click();
  await page.getByRole('button',{name:'Open Home AC Unit',exact:true}).click();
  await page.getByText('C123456789',{exact:true}).waitFor();
  assert.deepEqual(errors,[]); await page.close();
  console.log(`PASS dashboard, properties, vehicle/document creation, asset details at ${width}x${height}`);
 }
 await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
