const { chromium } = require('playwright');
const assert = require('node:assert/strict');
(async () => {
  const browser = await chromium.launch();
  for (const [width,height] of [[320,568],[390,844],[440,956]]) {
    const page = await browser.newPage({viewport:{width,height}});
    const errors = [];
    page.on('pageerror',e=>errors.push(e.message));
    await page.goto('http://localhost:8081');
    await page.getByRole('button',{name:'Get Started',exact:true}).click();
    await page.getByText('Explore demo without signing in',{exact:true}).click();
    await page.getByLabel('Workspace Name',{exact:true}).fill('My Workspace');
    await page.getByRole('button',{name:'Create Workspace',exact:true}).click();
    await page.getByText('Step 3 of 5',{exact:true}).waitFor();
    if(width===390) { await page.waitForLoadState('networkidle'); await page.locator('img').evaluateAll(images=>Promise.all(images.map(image=>image.decode().catch(()=>{})))); await page.screenshot({path:'previews/property-onboarding.png'}); }
    assert(await page.evaluate(()=>document.documentElement.scrollWidth <= innerWidth));
    await page.getByRole('button',{name:'Add Property',exact:true}).click();
    await page.getByRole('button',{name:'Save Property',exact:true}).click();
    await page.getByText('Enter a property name.',{exact:true}).waitFor();
    await page.getByLabel('Property Name',{exact:true}).fill('Lake Cottage');
    await page.getByLabel('Property Address (Optional)',{exact:true}).fill('123 Lake Road');
    await page.getByRole('button',{name:'Save Property',exact:true}).click();
    await page.getByRole('heading',{name:'Add Your First Asset',exact:true}).waitFor();
    await page.getByRole('button',{name:'Add Later',exact:true}).click();
    await page.getByRole('button',{name:'Select workspace',exact:true}).getByText('My Workspace',{exact:true}).waitFor();
    await page.getByRole('button',{name:'Assets',exact:true}).click();
    await page.getByPlaceholder('Search assets...').fill('Lake Cottage');
    await page.getByText('Lake Cottage',{exact:true}).waitFor();
    assert.deepEqual(errors,[]);
    await page.close();
    console.log(`PASS property onboarding, validation and saved property at ${width}x${height}`);
  }
  await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
