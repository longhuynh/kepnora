# Kepnora

A React Native / Expo app recreating the four supplied mockup screens: Dashboard, My Assets, Asset Details, and Find a Service Provider.

## Run

```sh
npm install
npm start
```

Open the project in a compatible Expo Go client or use `npm run android` / `npm run ios` with a configured emulator. iOS Simulator requires macOS. For a browser preview, use `npm run web`. `npm run build:web` produces a static web bundle.

## Source organization

- `App.js` — shared state, actions, and screen navigation.
- `src/screens/` — the welcome screen and all ten application screens, each in its own file.
- `src/components/` — reusable UI controls, maintenance cards, header, bottom navigation, and dialogs.
- `src/theme/` — shared colors and styles.
- `src/data/demoData.js` — sample assets, providers, and image references.

## App interactions

- Dashboard with maintenance, activity, and navigation.
- Searchable assets with category filters, adding, and renaming.
- Asset details with overview, maintenance, documents, and history tabs.
- Maintenance completion and undo.
- Provider search, service categories, favorites, location editing, and service/quote request forms.
- Safe-area support and a centered mobile layout on desktop browsers.

Images in `assets/` are cropped from the user-provided reference to retain its exact imagery. Their resolution is limited by that reference. UI is rendered using native components, rather than a full-screen mockup image.

This is an interactive frontend demo. Data and requests are held in memory and reset on reload. Provider listings and map locations are sample content; requests are not transmitted. Document file storage, authentication, persistent data, and real service integrations are not connected. Auto and HVAC categories have sample providers. Document records can be previewed and added; they are not uploaded files. Settings switches control demo state only.

## Navigation

Welcome → Create Account or Sign In → Explore demo → Dashboard → Assets → Asset Details → Maintenance Schedule → Find Services → Provider Details → Book Service → Date & Time → Review request → Maintenance.

The old splash-style screen has been replaced by the illustrated Welcome screen. Sign In and Create Account are separate screen files with shared form controls in `src/components/AuthUI.js`. Forms validate email, required fields, password length, matching passwords, and consent. Authentication, password recovery, Apple/Google OAuth, and production legal documents are not connected. Credentials are not persisted or transmitted; the explicit demo action enters the existing app.

`scripts/auth-smoke.cjs` checks the entry screens, validation, password visibility, recovery and social notices, and demo navigation.

Create Account now continues to `CreateWorkspaceScreen.js`. Enter a workspace name, select Primary Home, Rental Property, Vacation Home, or Other, and optionally add an address. Creating a workspace updates Dashboard and Settings for the current session; Skip for now retains the sample workspace. `scripts/workspace-smoke.cjs` checks validation, creation, property selection, skip, and responsive behavior.

After creating a workspace, `PropertyOnboardingScreen.js` presents the optional property step. Add Property opens a name/address form and adds the property to the demo asset list. Both saving and skipping continue to `AssetOnboardingScreen.js`. Choose Home, Vehicle, HVAC, Appliance, or Other Asset to enter a name and optional model/details. Saving adds the asset to its matching group and opens Dashboard; Add Later and Skip Asset also open Dashboard. Data remains in memory for the session. `scripts/property-smoke.cjs` and `scripts/asset-onboarding-smoke.cjs` verify these flows at three phone sizes.

The latest dashboard uses Home, Properties, Assets, and Documents in the bottom bar. Profile and workspace settings open Settings; Upcoming opens Maintenance. Other detail flows retain their navigation controls. The dashboard includes the welcome banner, four quick-add actions, property and asset cards, and upcoming reminders. `PropertiesScreen.js` lists property records; dashboard quick-add actions open the property/asset onboarding or document form. `scripts/dashboard-smoke.cjs` verifies the dashboard at three phone sizes. The displayed John/JH identity and upcoming dates are sample content from the reference.

`scripts/flow-smoke.cjs` exercises all ten screens and saves screenshots in `previews/`. Run with Playwright available and the exported web app served on port 8081.
