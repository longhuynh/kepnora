import React, { useState } from 'react';
import { View, Text, ScrollView, Modal, useWindowDimensions } from 'react-native';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { initialAssets } from './src/data/demoData';
import { s } from './src/theme/styles';
import { Tap } from './src/components/ui';
import WelcomeScreen from './src/screens/WelcomeScreen';
import SignInScreen from './src/screens/SignInScreen';
import CreateAccountScreen from './src/screens/CreateAccountScreen';
import CreateWorkspaceScreen from './src/screens/CreateWorkspaceScreen';
import PropertyOnboardingScreen from './src/screens/PropertyOnboardingScreen';
import AssetOnboardingScreen from './src/screens/AssetOnboardingScreen';
import DashboardScreen from './src/screens/DashboardScreen';
import PropertiesScreen from './src/screens/PropertiesScreen';
import MyAssetsScreen from './src/screens/MyAssetsScreen';
import AssetDetailsScreen from './src/screens/AssetDetailsScreen';
import ServiceProvidersScreen from './src/screens/ServiceProvidersScreen';
import MaintenanceCard from './src/components/MaintenanceCard';
import AppDialog from './src/components/AppDialog';
import AppHeader from './src/components/AppHeader';
import BottomNavigation from './src/components/BottomNavigation';
import MaintenanceScreen from './src/screens/MaintenanceScreen';
import ProviderDetailsScreen from './src/screens/ProviderDetailsScreen';
import BookServiceScreen from './src/screens/BookServiceScreen';
import BookDateScreen from './src/screens/BookDateScreen';
import DocumentsScreen from './src/screens/DocumentsScreen';
import SettingsScreen from './src/screens/SettingsScreen';
import { autoProviders, initialDocuments } from './src/data/serviceData';
import { Button, f } from './src/components/FlowUI';

export default function App() {
  const [screen, setScreen] = useState('Welcome');
  const [workspace, setWorkspace] = useState(null);
  const [workspaceDraft, setWorkspaceDraft] = useState({ name: '', type: 'Primary Home', address: '' });
  const [assets, setAssets] = useState(initialAssets);
  const [selected, setSelected] = useState(initialAssets.find(asset => asset.id === 'car'));
  const [filter, setFilter] = useState('All');
  const [query, setQuery] = useState('');
  const [serviceQuery, setServiceQuery] = useState('');
  const [category, setCategory] = useState('HVAC');
  const [tab, setTab] = useState('Overview');
  const [favorites, setFavorites] = useState([]);
  const [completion, setCompletion] = useState({});
  const completed = !!completion[screen === 'Details' ? selected.id : 'ac'];
  const setCompleted = (value) => setCompletion(previous => ({ ...previous, [selected.id]: value }));
  const [location, setLocation] = useState('Cypress, TX 77433');
  const [dialog, setDialog] = useState(null);
  const [input, setInput] = useState('');
  const [notice, setNotice] = useState('');
  const [history, setHistory] = useState([]);
  const [provider, setProvider] = useState(autoProviders[0]);
  const [bookingService, setBookingService] = useState(null);
  const [bookingDate, setBookingDate] = useState('');
  const [bookingTime, setBookingTime] = useState('');
  const [reviewBooking, setReviewBooking] = useState(false);
  const [documents, setDocuments] = useState(initialDocuments);
  const [tasks, setTasks] = useState([
    { id: 'oil', assetId: 'car', title: 'Oil Change', due: 'Due in 12 days', rule: 'Every 5,000 miles', done: false },
    { id: 'tires', assetId: 'car', title: 'Tire Rotation', due: 'Due in 1,200 miles', rule: 'Every 7,500 miles', done: false },
    { id: 'brakes', assetId: 'car', title: 'Brake Inspection', due: 'Due in 3 months', rule: 'Every 12 months', done: false },
    { id: 'filter', assetId: 'ac', title: 'Replace Air Filter', due: 'Due in 3 days', rule: 'Every 3 months', done: false },
    { id: 'flush', assetId: 'water', title: 'Flush Tank', due: 'Due in 2 weeks', rule: 'Every 12 months', done: false },
  ]);
  const { width } = useWindowDimensions();
  const go = (next) => { setHistory(previous => next === 'Welcome' ? [] : [...previous, screen]); setScreen(next); setNotice(''); };
  const back = () => { setScreen(history[history.length - 1] || 'Home'); setHistory(previous => previous.slice(0, -1)); setNotice(''); };
  const onProvider = (value) => { setProvider(value); setBookingService(null); setBookingDate(''); setBookingTime(''); go('Provider'); };
  const findService = () => { setCategory(selected.id === 'car' ? 'Auto' : 'HVAC'); setServiceQuery(''); go('Services'); };
  const detail = (asset) => { setDialog(null); setSelected(asset); setTab('Overview'); go('Details'); };
  const open = (kind, title, value = '') => { setInput(value); setDialog({ kind, title }); };
  const save = () => {
    if (!input.trim()) return;
    if (dialog.kind === 'location') setLocation(input.trim());
    if (dialog.kind === 'notes') { const updated = { ...selected, notes: input.trim() }; setSelected(updated); setAssets(assets.map(a => a.id === selected.id ? updated : a)); }
    if (dialog.kind === 'edit') { const updated = { ...selected, name: input.trim() }; setSelected(updated); setAssets(assets.map(a => a.id === selected.id ? updated : a)); }
    if (dialog.kind === 'add') { setAssets([...assets, { id: `custom-${Date.now()}`, name: input.trim(), model: 'Personal asset', place: 'Personal', group: 'Other', category: 'Personal', brand: '—' }]); go('Assets'); }
    if (dialog.kind === 'quote') setNotice('Quote request saved. Connect a service account to send it to local pros.');
    if (dialog.kind === 'schedule') setNotice(`Service request saved for ${input.trim()}. Provider confirmation is pending.`);
    setDialog(null);
  };
  const maintenance = [ { image: 'ac', title: 'HVAC - Replace Air Filter', due: completed ? 'Completed today' : 'Due in 3 days', place: 'Home • HVAC', urgent: !completed }, { image: 'water', title: 'Water Heater - Flush Tank', due: 'Due in 2 weeks', place: 'Home • Water Heater' }, { image: 'car', title: 'Toyota Camry - Oil Change', due: 'Due in 1 month', place: 'Vehicle • Engine' } ];
  const renderMaintenance = (item) => <MaintenanceCard key={item.image} item={item} onPress={() => detail(assets.find(asset => asset.id === item.image))} />;
  if (screen === 'Welcome') return <WelcomeScreen go={go} />;
  if (screen === 'SignIn') return <SignInScreen go={go} onDemo={() => go('Home')} />;
  if (screen === 'CreateAccount') return <CreateAccountScreen go={go} onDemo={() => go('CreateWorkspace')} />;
  if (screen === 'CreateWorkspace') return <CreateWorkspaceScreen go={go} draft={workspaceDraft} setDraft={setWorkspaceDraft} onCreate={value => { setWorkspace(value); go('PropertyOnboarding'); }} />;
  if (screen === 'PropertyOnboarding') return <PropertyOnboardingScreen workspace={workspace} go={go} onAdd={property => { setAssets(previous => [...previous, { id: `property-${Date.now()}`, name: property.name, model: property.type, place: property.address || 'No address added', group: 'Home', category: 'Property', brand: '—', imageSource: require('./assets/property-onboarding-house.png') }]); go('AssetOnboarding'); }} />;
  if (screen === 'AssetOnboarding') return <AssetOnboardingScreen workspace={workspace} go={go} onAdd={asset => { setAssets(previous => [...previous, { ...asset, id: `asset-${Date.now()}`, place: workspace?.name || 'Personal', brand: '—' }]); go('Home'); setNotice(`${asset.name} added to ${workspace?.name || 'your workspace'}.`); }} />;
  if (screen === 'AddVehicle') return <AssetOnboardingScreen initialCategory="Vehicle" workspace={workspace} go={go} onAdd={asset => { setAssets(previous => [...previous, { ...asset, id: `asset-${Date.now()}`, place: workspace?.name || 'Personal', brand: '—' }]); go('Home'); setNotice(`${asset.name} added.`); }} />;
  return <SafeAreaProvider><View style={s.canvas}><SafeAreaView style={[s.app, width > 600 && s.desktop]}><StatusBar style="dark" />
    <AppHeader screen={screen} selected={selected} go={go} open={open} back={back} />
    <ScrollView key={screen} showsVerticalScrollIndicator={false} contentContainerStyle={s.content}>
      {!!notice && <Tap style={s.notice} onPress={() => setNotice('')}><Text style={s.small}>{notice}</Text></Tap>}
      {screen === 'Home' && <DashboardScreen workspace={workspace} assets={assets} completed={completed} go={go} open={open} detail={detail} onAddVehicle={() => go('AddVehicle')} onAddDocument={() => go('AddDocument')} onMaintenance={() => { setSelected(assets.find(asset => asset.id === 'ac')); go('Maintenance'); }} />}
      {screen === 'Properties' && <PropertiesScreen assets={assets} detail={detail} go={go} />}
      {screen === 'Assets' && <MyAssetsScreen assets={assets} query={query} setQuery={setQuery} filter={filter} setFilter={setFilter} detail={detail} />}
      {screen === 'Details' && <AssetDetailsScreen selected={selected} tab={tab} setTab={setTab} completed={completed} setCompleted={setCompleted} setNotice={setNotice} open={open} go={go} findService={findService} />}
      {screen === 'Services' && <ServiceProvidersScreen location={location} serviceQuery={serviceQuery} setServiceQuery={setServiceQuery} category={category} setCategory={setCategory} favorites={favorites} setFavorites={setFavorites} open={open} onProvider={onProvider} />}
      {screen === 'Maintenance' && <MaintenanceScreen selected={selected} go={go} tasks={tasks} setTasks={setTasks} onFindService={findService} />}
      {screen === 'Provider' && <ProviderDetailsScreen provider={provider} favorites={favorites} setFavorites={setFavorites} go={go} setNotice={setNotice} />}
      {screen === 'BookService' && <BookServiceScreen provider={provider} bookingService={bookingService} setBookingService={setBookingService} go={go} />}
      {screen === 'BookDate' && <BookDateScreen bookingDate={bookingDate} setBookingDate={setBookingDate} bookingTime={bookingTime} setBookingTime={setBookingTime} onReview={() => setReviewBooking(true)} />}
      {screen === 'Documents' && <DocumentsScreen documents={documents} setDocuments={setDocuments} />}
      {screen === 'AddDocument' && <DocumentsScreen initialAdding documents={documents} setDocuments={setDocuments} />}
      {screen === 'Settings' && <SettingsScreen go={go} workspace={workspace} />}
    </ScrollView>
    <BottomNavigation screen={screen} open={open} go={go} />
    <Modal visible={reviewBooking} transparent animationType="fade" onRequestClose={() => setReviewBooking(false)}><View style={s.backdrop}><View style={s.dialog}><Text style={f.title}>Review Booking</Text><Text style={f.text}>{provider.name}</Text><Text style={f.text}>{bookingService?.name} · From ${bookingService?.price.toFixed(2)}</Text><Text style={f.text}>{bookingDate} at {bookingTime}</Text><Text style={[f.caption, { marginVertical: 12 }]}>This saves a demo request. It does not contact the provider or reserve an appointment.</Text><Button title="Confirm Request" onPress={() => { setTasks([...tasks, { id: String(Date.now()), assetId: selected.id, title: bookingService.name, due: `${bookingDate} · ${bookingTime}`, rule: `${provider.name} · Pending confirmation`, done: false }]); setReviewBooking(false); go('Maintenance'); setNotice('Request saved for this session. Provider confirmation is pending.'); }} /><Tap onPress={() => setReviewBooking(false)}><Text style={f.text}>Back to date & time</Text></Tap></View></View></Modal>
    <AppDialog dialog={dialog} setDialog={setDialog} input={input} setInput={setInput} save={save} maintenance={maintenance} renderMaintenance={renderMaintenance} favorites={favorites} assets={assets} completed={completed} go={go} />
  </SafeAreaView>{width > 600 && <Text style={s.desktopCaption}>KEPNORA  /  Everything you own, well cared for.</Text>}</View></SafeAreaProvider>;
}

