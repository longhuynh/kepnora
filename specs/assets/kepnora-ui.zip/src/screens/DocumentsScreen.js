import React, { useState } from 'react';
import { View, Text, Image, Modal, TextInput } from 'react-native';
import { Tap, Icon, Search } from '../components/ui';
import { Tabs, Button, f } from '../components/FlowUI';
export default function DocumentsScreen({ documents, setDocuments, initialAdding = false }) {
  const [filter, setFilter] = useState('All');
  const [query, setQuery] = useState('');
  const [selected, setSelected] = useState(null);
  const [adding, setAdding] = useState(initialAdding);
  const [title, setTitle] = useState('');
  const visible = documents.filter(d => (filter === 'All' || filter === d.type) && `${d.title} ${d.asset}`.toLowerCase().includes(query.toLowerCase()));
  return <><Tabs value={filter} onChange={setFilter} items={['All', 'Receipts', 'Photos', 'Manuals'].map(value => ({ value, label: `${value} (${documents.filter(d => value === 'All' || d.type === value).length})` }))} /><Search placeholder="Search documents..." value={query} onChangeText={setQuery} /><View style={{ height: 18 }} />{visible.map(d => <Tap key={d.id} onPress={() => setSelected(d)} style={[f.card, f.row]}>{d.image ? <Image source={d.image} style={{ width: 42, height: 53, borderRadius: 5 }} /> : <View style={f.iconBox}><Icon name={d.icon || 'document-text'} color={d.id === 'manual' ? '#ee4c47' : '#227eff'} size={32} /></View>}<View style={f.flex}><Text style={f.title}>{d.title}</Text><Text style={f.caption}>{d.asset} · {d.kind}</Text><Text style={f.caption}>{d.date} · {d.size}</Text></View><Icon name="chevron-forward" size={16} /></Tap>)}{!visible.length && <Text style={f.empty}>No matching documents.</Text>}
    <Button title={adding ? 'Cancel' : 'Add Document'} icon="add" onPress={() => setAdding(!adding)} />{adding && <View style={f.card}><Text style={f.title}>Add a document record</Text><Text style={f.caption}>Save a title now. File storage is not connected.</Text><TextInput accessibilityLabel="Document title" value={title} onChangeText={setTitle} placeholder="Document title" style={f.input} /><Button title="Save document record" disabled={!title.trim()} onPress={() => { setDocuments([...documents, { id: String(Date.now()), title: title.trim(), asset: 'Personal', type: 'Manuals', kind: 'Document', date: new Date().toLocaleDateString(), size: 'No file attached', description: 'Document record only. No file has been uploaded.' }]); setTitle(''); setAdding(false); setFilter('All'); }} /></View>}
    <Modal visible={!!selected} transparent animationType="fade" onRequestClose={() => setSelected(null)}><View style={{ flex: 1, backgroundColor: '#06234488', justifyContent: 'center', padding: 24 }}><View style={[f.card, { width: '100%', maxWidth: 400, alignSelf: 'center' }]}><Text style={f.title}>{selected?.title}</Text>{selected?.image && <Image source={selected.image} resizeMode="contain" style={{ height: 160, width: '100%', marginVertical: 15 }} />}<Text style={f.text}>{selected?.description}</Text><Text style={[f.caption, { marginTop: 10 }]}>{selected?.asset} · {selected?.date}</Text><Button title="Close document" onPress={() => setSelected(null)} /></View></View></Modal>
  </>;
}
