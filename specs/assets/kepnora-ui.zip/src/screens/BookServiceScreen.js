import React from 'react';
import { View, Text } from 'react-native';
import { Tap, Icon } from '../components/ui';
import { Steps, Button, f } from '../components/FlowUI';
import { serviceOptions } from '../data/serviceData';
export default function BookServiceScreen({ provider, bookingService, setBookingService, go }) {
  const options = provider.tags.includes('HVAC') ? [{ name: 'AC Maintenance', price: 89.99 }, { name: 'Air Filter Replacement', price: 39.99 }, { name: 'Diagnostic Inspection', price: 79.99 }] : serviceOptions.map((s, i) => i === 0 ? { ...s, price: provider.price || s.price } : s);
  return <><Steps step={0} /><Text style={f.caption}>{provider.name}</Text><Text style={[f.title, { marginVertical: 16 }]}>Select Service</Text>{options.map(option => <Tap key={option.name} onPress={() => setBookingService(option)} style={[f.card, f.row, bookingService?.name === option.name && { borderColor: '#227eff', backgroundColor: '#f4f9ff' }]}><View style={f.iconBox}><Icon name={option.name.includes('Oil') ? 'water' : option.name.includes('Tire') ? 'ellipse' : option.name.includes('Brake') ? 'disc' : 'clipboard'} color='#17212c' size={28} /></View><View style={f.flex}><Text style={f.text}>{option.name}</Text><Text style={f.caption}>From ${option.price.toFixed(2)}</Text></View><Icon name={bookingService?.name === option.name ? 'checkmark-circle' : 'ellipse-outline'} color={bookingService?.name === option.name ? '#227eff' : '#aab8c9'} /></Tap>)}<Button title="Next" disabled={!bookingService} onPress={() => go('BookDate')} /></>;
}
