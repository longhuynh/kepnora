import React from 'react';
import { View, Text, Image } from 'react-native';
import { C } from '../theme/colors';
import { s } from '../theme/styles';
import { Icon, Tap, Badge, Search } from '../components/ui';
import { imageFor } from '../data/demoData';

export default function MyAssetsScreen({ assets, query, setQuery, filter, setFilter, detail }) {
  return <>
        <Search value={query} onChangeText={setQuery} placeholder="Search assets..." />
        <View style={s.filters}>{['All', 'Home', 'Vehicles', 'Other'].map(f => <Tap key={f} style={[s.chip, filter === f && s.selectedChip]} onPress={() => setFilter(f)}><Text style={[s.chipText, filter === f && s.white]}>{f} ({f === 'All' ? assets.length : assets.filter(a => a.group === f).length})</Text></Tap>)}</View>
        {assets.filter(a => (filter === 'All' || a.group === filter) && `${a.name} ${a.model}`.toLowerCase().includes(query.toLowerCase())).map(a => <Tap key={a.id} style={s.assetCard} onPress={() => detail(a)}><Image source={imageFor(a)} style={s.assetImage} /><View style={s.flex}><Text style={s.cardTitle}>{a.name}</Text><Text style={s.small}>{a.place}</Text>{a.id === 'car' ? <Text style={s.small}>24,300 miles</Text> : a.id === 'ac' ? <Text style={{ color: '#009767', fontSize: 11 }}>Good condition</Text> : null}</View><Icon name="chevron-forward" size={17} color={C.muted} /></Tap>)}
        {!assets.some(a => (filter === 'All' || a.group === filter) && `${a.name} ${a.model}`.toLowerCase().includes(query.toLowerCase())) && <Text style={s.empty}>No assets found. Try another search.</Text>}
  </>;
}
