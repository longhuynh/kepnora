import React from 'react';
import { View, Text, Image } from 'react-native';
import { Tap, Icon } from '../components/ui';
import { Button, f } from '../components/FlowUI';
import { imageFor } from '../data/demoData';
export default function PropertiesScreen({ assets, detail, go }) {
  const properties = assets.filter(asset => asset.category === 'Property');
  return <>{properties.map(property => <Tap key={property.id} style={[f.card, f.row]} onPress={() => detail(property)}><Image source={imageFor(property)} style={{ width: 80, height: 70, borderRadius: 12 }} /><View style={f.flex}><Text style={f.title}>{property.name}</Text><Text style={f.caption}>{property.place}</Text><Text style={{ color: '#00a994', fontSize: 12, marginTop: 5 }}>{property.model}</Text></View><Icon name="chevron-forward" size={18} /></Tap>)}{!properties.length && <Text style={f.empty}>No properties yet.</Text>}<Button title="Add Property" icon="add" onPress={() => go('PropertyOnboarding')} /></>;
}
