import React, { useState } from 'react';
import { View, Text, Modal } from 'react-native';
import { Tap } from '../components/ui';
import { AuthLayout, AuthField, AuthButton, SocialButtons, AuthNotice, emailValid, useAuthStyles } from '../components/AuthUI';
import { s } from '../theme/styles';
export default function SignInScreen({ go, onDemo }) {
  const a = useAuthStyles();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState({});
  const [message, setMessage] = useState(null);
  const [valid, setValid] = useState(false);
  const [reset, setReset] = useState(false);
  const [resetEmail, setResetEmail] = useState('');
  const [resetError, setResetError] = useState('');
  const submit = () => { const next = {}; if (!emailValid(email)) next.email = 'Enter a valid email address.'; if (!password) next.password = 'Enter your password.'; setErrors(next); setValid(!Object.keys(next).length); };
  return <AuthLayout onBack={() => go('Welcome')}><View style={a.panel}><Text accessibilityRole="header" style={a.heading}>Sign In</Text><Text style={a.description}>Welcome back! Sign in to continue managing your assets.</Text>
    <AuthField label="Email" icon="mail-outline" value={email} onChangeText={setEmail} placeholder="your@email.com" keyboardType="email-address" autoComplete="email" error={errors.email} />
    <AuthField label="Password" icon="lock-closed-outline" value={password} onChangeText={setPassword} placeholder="Enter your password" password autoComplete="current-password" error={errors.password} />
    <Tap style={{ alignSelf: 'flex-end', marginBottom: 12 }} onPress={() => { setResetEmail(email); setReset(true); }}><Text style={a.link}>Forgot password?</Text></Tap>
    <AuthButton title="Sign In" onPress={submit} />{valid && <View style={a.success}><Text style={a.muted}>Form validated. Sign-in is not connected yet; you can explore the demo below.</Text><AuthButton title="Continue to demo" onPress={onDemo} /></View>}
    <SocialButtons onPress={provider => setMessage({ title: `Continue with ${provider}`, body: `${provider} sign-in is not connected in this demo. No account has been accessed.` })} />
    <View style={a.footer}><Text style={a.muted}>Don’t have an account?</Text><Tap onPress={() => go('CreateAccount')}><Text style={a.link}>Sign Up</Text></Tap></View>
  </View><Tap style={a.demo} onPress={onDemo}><Text style={[a.link, { fontSize: 12 }]}>Explore demo without signing in</Text></Tap>
    <AuthNotice message={message} onClose={() => setMessage(null)} />
    <Modal visible={reset} transparent animationType="fade" onRequestClose={() => setReset(false)}><View style={s.backdrop}><View style={s.dialog}><Text style={a.heading}>Reset Password</Text><Text style={a.description}>Enter the email associated with your account.</Text><AuthField label="Recovery email" icon="mail-outline" value={resetEmail} onChangeText={setResetEmail} placeholder="your@email.com" keyboardType="email-address" error={resetError} /><AuthButton title="Send reset link" onPress={() => { if (!emailValid(resetEmail)) { setResetError('Enter a valid email address.'); return; } setReset(false); setResetError(''); setMessage({ title: 'Password recovery', body: 'Password recovery is not connected yet. No email was sent.' }); }} /><Tap style={a.demo} onPress={() => setReset(false)}><Text style={a.link}>Cancel</Text></Tap></View></View></Modal>
  </AuthLayout>;
}
