import React from 'react';
import { View, Text, Image, StyleSheet } from 'react-native';
import { Icon, Tap } from '../components/ui';
import { AuthLayout, AuthButton, a, useAuthSize } from '../components/AuthUI';
export default function WelcomeScreen({ go }) {
  return <AuthLayout welcome><WelcomeContent go={go} /></AuthLayout>;
}
function WelcomeContent({ go }) {
  const { height, width } = useAuthSize();
  const scale = Math.max(.55, Math.min(1.12, (height - 210) / 610));
  const responsive = { brand: { paddingTop: 24 * scale, paddingBottom: 16 * scale }, logo: { width: 188 * scale, height: 142 * scale }, house: { height: 220 * scale }, features: { paddingBottom: 12 * scale }, circle: { width: 48 * scale, height: 48 * scale }, actions: { paddingHorizontal: width < 360 ? 16 : 28 } };
  const styles = Object.fromEntries(Object.entries(w).map(([key, value]) => [key, [value, responsive[key]]]));
  return <View style={{ flexGrow: 1, justifyContent: 'center' }}><View style={styles.brand}><Image source={require('../../assets/onboarding-brand-transparent.png')} accessibilityLabel="Kepnora" style={styles.logo} resizeMode="contain" /><Text style={w.tagline}>Everything You Own,{ '\n' }Well Cared For.</Text></View>
    <View style={w.features}>{[['Track\nYour Assets', 'home', '#0065ff'], ['Manage\nMaintenance', 'construct', '#00afa8'], ['Keep Important\nDocuments', 'document-text', '#0065ff']].map(([label, icon, color]) => <View key={label} style={w.feature}><View style={[w.circle, { backgroundColor: color === '#00afa8' ? '#e0f8f8' : '#e9f4ff' }]}><Icon name={icon} size={26} color={color} /></View><Text style={w.featureText}>{label}</Text></View>)}</View>
    <Image source={require('../../assets/onboarding-house.png')} accessibilityLabel="A well cared for family home at dusk" style={styles.house} resizeMode="cover" />
    <View style={w.actions}><View accessibilityLabel="Welcome" style={w.dots}><View style={[w.dot, { backgroundColor: '#0065ff' }]} /><View style={w.dot} /><View style={w.dot} /></View><AuthButton title="Get Started" onPress={() => go('CreateAccount')} /><AuthButton title="Sign In" secondary onPress={() => go('SignIn')} /><View style={[a.footer, { marginTop: 22 }]}><Text style={a.muted}>Don’t have an account?</Text><Tap onPress={() => go('CreateAccount')}><Text style={a.link}>Sign Up</Text></Tap></View></View>
  </View>;
}
const w = StyleSheet.create({ brand: { alignItems: 'center', paddingTop: 35, paddingBottom: 23 }, logo: { width: 188, height: 142 }, tagline: { fontSize: 18, fontWeight: '500', color: '#718ba6', lineHeight: 25, textAlign: 'center', marginTop: 9 }, features: { flexDirection: 'row', paddingHorizontal: 14, paddingBottom: 15 }, feature: { flex: 1, alignItems: 'center', gap: 7 }, circle: { width: 52, height: 52, borderRadius: 26, alignItems: 'center', justifyContent: 'center' }, featureText: { fontSize: 12, color: '#34546c', textAlign: 'center', lineHeight: 18 }, house: { width: '100%', height: 220 }, actions: { paddingHorizontal: 28, paddingBottom: 10, marginTop: -2 }, dots: { flexDirection: 'row', justifyContent: 'center', gap: 9, marginVertical: 12 }, dot: { width: 6, height: 6, borderRadius: 3, backgroundColor: '#cbdbe0' } });
