import React, { useState } from 'react';
import { View, Text, Image, StyleSheet, Modal, ScrollView, KeyboardAvoidingView, Platform } from 'react-native';
import { AuthLayout, AuthButton, AuthField, useAuthSize, a } from '../components/AuthUI';
import { Tap, Icon } from '../components/ui';
import { s } from '../theme/styles';

const benefits = [
  ['Keep everything organized', 'Store details, documents, and photos in one place.', 'home-outline', '#00ac9e', '#e4f8f4'],
  ['Track maintenance', 'Never miss important service or warranty dates.', 'build-outline', '#087bff', '#e9f3ff'],
  ['Know your property value', 'Keep notes, improvements, and history over time.', 'document-text-outline', '#a068e9', '#f2ebff'],
];
export default function PropertyOnboardingScreen(props) {
  return <AuthLayout welcome><PropertyContent {...props} /></AuthLayout>;
}
function PropertyContent({ workspace, onAdd, go }) {
  const { width, height } = useAuthSize();
  const [adding, setAdding] = useState(false);
  const [name, setName] = useState('');
  const [address, setAddress] = useState(workspace?.address || '');
  const [error, setError] = useState('');
  const illustrationHeight = Math.max(140, Math.min(width * .55, height * .25));
  return <View style={p.page}>
    <View style={p.header}>
      <View style={p.brand}><Image source={require('../../assets/onboarding-brand-transparent.png')} accessibilityLabel="Kepnora" resizeMode="contain" style={p.logo} /><Text style={p.tagline}>Everything You Own,{ '\n' }Well Cared For.</Text></View>
      <View accessibilityLabel="Onboarding step 3 of 5" style={p.progress}><View style={p.bars}>{[0,1,2,3,4].map(i => <View key={i} style={[p.bar, i < 3 && { backgroundColor: '#009dd5' }]} />)}</View><Text style={p.step}>Step 3 of 5</Text></View>
    </View>
    <Image source={require('../../assets/property-onboarding-house.png')} accessibilityLabel="Illustration of a home with trees and a driveway" resizeMode="contain" style={{ width: '100%', height: illustrationHeight }} />
    <Text accessibilityRole="header" style={p.title}>Add a Property{ '\n' }(Optional)</Text>
    <Text style={p.intro}>Add your first property to start tracking maintenance, documents, and value.{ '\n' }You can always add more properties later.</Text>
    <View style={p.benefits}>{benefits.map(([title, detail, icon, color, backgroundColor]) => <View key={title} style={p.benefit}><View style={[p.circle, { backgroundColor }]}><Icon name={icon} color={color} size={28} /></View><View style={{ flex: 1 }}><Text style={p.benefitTitle}>{title}</Text><Text style={p.description}>{detail}</Text></View></View>)}</View>
    <View style={p.actions}><AuthButton title="Add Property" onPress={() => setAdding(true)} /><AuthButton title="Skip for Now" secondary onPress={() => go('AssetOnboarding')} /></View>
    <Modal visible={adding} transparent animationType="fade" onRequestClose={() => setAdding(false)}><KeyboardAvoidingView style={s.backdrop} behavior={Platform.OS === 'ios' ? 'padding' : undefined}><View style={[s.dialog, { maxHeight: '90%' }]}><ScrollView keyboardShouldPersistTaps="handled"><View style={[p.header, { marginBottom: 18 }]}><Text style={[a.heading, { flex: 1, fontSize: 25 }]}>Add Property</Text><Tap label="Close property form" onPress={() => setAdding(false)}><Icon name="close" /></Tap></View><AuthField label="Property Name" icon="home-outline" placeholder="e.g. My Home" autoCapitalize="words" value={name} onChangeText={value => { setName(value); setError(''); }} error={error} maxLength={80} /><AuthField label="Property Address (Optional)" icon="location-outline" placeholder="Enter property address" autoCapitalize="words" value={address} onChangeText={setAddress} /><Text style={a.hint}>Added to {workspace?.name || 'your demo workspace'}. Saved for this session only.</Text><AuthButton title="Save Property" onPress={() => { if (!name.trim()) { setError('Enter a property name.'); return; } onAdd({ name: name.trim(), address: address.trim(), type: workspace?.type || 'Primary Home' }); }} /></ScrollView></View></KeyboardAvoidingView></Modal>
  </View>;
}
const p = StyleSheet.create({
  page: { flexGrow: 1, paddingHorizontal: 23, paddingTop: 17, paddingBottom: 20, backgroundColor: '#f9fcff' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' }, brand: { alignItems: 'center' },
  logo: { width: 104, height: 79 }, tagline: { color: '#7b91aa', fontSize: 10, lineHeight: 14, textAlign: 'center', marginTop: 5 },
  progress: { marginTop: 15, alignItems: 'flex-end', width: '36%' }, bars: { flexDirection: 'row', gap: 3, width: '100%' }, bar: { flex: 1, height: 4, borderRadius: 3, backgroundColor: '#e5ecf5' }, step: { fontSize: 11, color: '#8398b1', marginTop: 9, fontWeight: '600' },
  title: { color: '#052c44', fontWeight: '800', fontSize: 29, lineHeight: 35, letterSpacing: -.6, textAlign: 'center', marginTop: 7 },
  intro: { color: '#7b90aa', fontSize: 14, lineHeight: 20, textAlign: 'center', marginTop: 12 }, benefits: { gap: 18, marginTop: 23, marginBottom: 13 },
  benefit: { flexDirection: 'row', alignItems: 'center', gap: 16 }, circle: { width: 51, height: 51, borderRadius: 26, alignItems: 'center', justifyContent: 'center' },
  benefitTitle: { color: '#0b2c46', fontSize: 14, fontWeight: '700', lineHeight: 20, letterSpacing: -.3 }, description: { color: '#7c91ab', fontSize: 13, lineHeight: 18, marginTop: 2 }, actions: { marginTop: 'auto', paddingTop: 8 },
});
