import React, { useState } from 'react';
import { View, Text, Pressable } from 'react-native';
import { Tap, Icon } from '../components/ui';
import { AuthLayout, AuthField, AuthButton, SocialButtons, AuthNotice, emailValid, useAuthStyles } from '../components/AuthUI';
export default function CreateAccountScreen({ go, onDemo }) {
  const [name, setName] = useState('');
  const a = useAuthStyles('create');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [agreed, setAgreed] = useState(false);
  const [errors, setErrors] = useState({});
  const [message, setMessage] = useState(null);
  const [valid, setValid] = useState(false);
  const submit = () => { const next = {}; if (!name.trim()) next.name = 'Enter your full name.'; if (!emailValid(email)) next.email = 'Enter a valid email address.'; if (password.length < 8 || !/[A-Za-z]/.test(password) || !/\d/.test(password)) next.password = 'Use at least 8 characters with a letter and number.'; if (!confirm || confirm !== password) next.confirm = 'Passwords must match.'; if (!agreed) next.agreed = 'Please agree to the Terms of Service and Privacy Policy.'; setErrors(next); setValid(!Object.keys(next).length); };
  return <AuthLayout variant="create" onBack={() => go('Welcome')}><View style={a.panel}><Text accessibilityRole="header" style={a.heading}>Create Account</Text><Text style={a.description}>Get started with Kepnora to manage your home, vehicles, and more.</Text>
    <AuthField label="Full Name" icon="person-outline" value={name} onChangeText={setName} placeholder="John Doe" autoCapitalize="words" autoComplete="name" error={errors.name} />
    <AuthField label="Email" icon="mail-outline" value={email} onChangeText={setEmail} placeholder="your@email.com" keyboardType="email-address" autoComplete="email" error={errors.email} />
    <AuthField label="Password" icon="lock-closed-outline" value={password} onChangeText={setPassword} placeholder="Create a password" password autoComplete="new-password" hint="At least 8 characters with a number and letter." error={errors.password} />
    <AuthField label="Confirm Password" icon="lock-closed-outline" value={confirm} onChangeText={setConfirm} placeholder="Confirm your password" password autoComplete="new-password" error={errors.confirm} />
    <View style={{ flexDirection: 'row', gap: 9, marginVertical: 7 }}><Pressable accessibilityRole="checkbox" accessibilityLabel="Agree to Terms of Service and Privacy Policy" accessibilityState={{ checked: agreed }} onPress={() => setAgreed(!agreed)} style={[a.check, !agreed && { backgroundColor: '#fff', borderWidth: 1, borderColor: '#a8bbce' }]}>{agreed && <Icon name="checkmark" size={17} color="white" />}</Pressable><Text style={{ flex: 1, fontSize: 12, lineHeight: 20, color: '#25445f' }}>I agree to the <Text accessibilityRole="link" style={{ color: '#0065ff' }} onPress={() => setMessage({ title: 'Terms of Service', body: 'The production Terms of Service have not been supplied. This demo does not create an account or submit your agreement.' })}>Terms of Service</Text> and <Text accessibilityRole="link" style={{ color: '#0065ff' }} onPress={() => setMessage({ title: 'Privacy Policy', body: 'The production Privacy Policy has not been supplied. This form does not transmit or save credentials.' })}>Privacy Policy.</Text></Text></View>{errors.agreed && <Text accessibilityRole="alert" style={a.error}>{errors.agreed}</Text>}
    <AuthButton title="Create Account" onPress={submit} />{valid && <View style={a.success}><Text style={a.muted}>Form validated. Account creation is not connected yet. Your credentials have not been saved.</Text><AuthButton title="Continue to demo" onPress={onDemo} /></View>}
    <SocialButtons onPress={provider => setMessage({ title: `Continue with ${provider}`, body: `${provider} sign-in is not connected in this demo. No account has been created.` })} /><View style={a.footer}><Text style={a.muted}>Already have an account?</Text><Tap onPress={() => go('SignIn')}><Text style={a.link}>Sign In</Text></Tap></View>
  </View><Tap style={a.demo} onPress={onDemo}><Text style={[a.link, { fontSize: 12 }]}>Explore demo without signing in</Text></Tap><AuthNotice message={message} onClose={() => setMessage(null)} /></AuthLayout>;
}
