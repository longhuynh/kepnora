import React, { useState } from 'react';
import { View, Text, Image } from 'react-native';
import { Tap, Icon } from '../components/ui';
import { Tabs, Button, f } from '../components/FlowUI';
import { pics } from '../data/demoData';
import { serviceOptions } from '../data/serviceData';
export default function ProviderDetailsScreen({ provider, favorites, setFavorites, go, setNotice }) {
  const [tab, setTab] = useState('Overview');
  const photo = provider.imageSource || pics[provider.image];
  const saved = favorites.includes(provider.name);
  return <><Image source={photo} style={{ width: '100%', height: 200, borderRadius: 18 }} /><View style={[f.card, { marginTop: 10 }]}><View style={f.row}><Text style={[f.title, f.flex]}>{provider.name}</Text><Tap label="Save provider" onPress={() => setFavorites(saved ? favorites.filter(n => n !== provider.name) : [...favorites, provider.name])}><Icon name={saved ? 'heart' : 'heart-outline'} color="#087cff" /></Tap></View><Text style={f.text}><Text style={{ color: '#f6a400' }}>★ {provider.rating}</Text> ({provider.reviews} reviews)</Text><Text style={f.caption}>{provider.tags.includes('HVAC') ? 'Home services' : 'Auto Repair Shop'} · {provider.distance} miles</Text><Text style={[f.caption, { color: '#009c68', marginTop: 5 }]}>● Open now · Closes 6:00 PM</Text></View><Tabs items={['Overview', 'Services', 'Reviews', 'Photos']} value={tab} onChange={setTab} />
    {tab === 'Overview' && <><View style={[f.row, { justifyContent: 'space-between', marginBottom: 15 }]}>{[['Call', 'call'], ['Directions', 'location'], ['Website', 'globe'], ['Share', 'star-outline']].map(([label, icon]) => <Tap key={label} style={{ alignItems: 'center', backgroundColor: '#eef5fc', padding: 13, borderRadius: 10 }} onPress={() => label === 'Directions' ? go('Services') : setNotice(`${label}: contact and sharing integrations are not connected for this sample provider.`)}><Icon name={icon} color="#087cff" /><Text style={f.caption}>{label}</Text></Tap>)}</View><View style={f.card}><Text style={f.text}>{provider.address || 'Cypress, TX'}</Text><Text style={f.caption}>Cypress, TX 77433</Text><Text style={[f.text, { marginTop: 16 }]}>Reliable care for the things you depend on.</Text><Text style={f.caption}>Monday–Friday 8:00 AM–6:00 PM{ '\n' }Saturday 9:00 AM–4:00 PM · Sunday closed</Text></View></>}
    {tab === 'Services' && (provider.tags.includes('HVAC') ? [{ name: 'AC Maintenance', price: 89.99 }] : serviceOptions).map(service => <View key={service.name} style={[f.card, f.row]}><Text style={[f.text, f.flex]}>{service.name}</Text><Text style={f.caption}>From ${service.price.toFixed(2)}</Text></View>)}
    {tab === 'Reviews' && <View style={f.card}><Text style={f.title}>★ {provider.rating} · {provider.reviews} reviews</Text><Text style={f.caption}>Sample review totals. Individual customer reviews are not connected.</Text></View>}
    {tab === 'Photos' && <Image source={photo} style={{ width: '100%', height: 220, borderRadius: 12 }} />}
    <Button title="Book Service" icon="calendar-outline" onPress={() => go('BookService')} /></>;
}
