import React, { useState } from 'react';
import { View, Text, Image, TextInput } from 'react-native';
import { Tap, Icon } from '../components/ui';
import { Tabs, Button, f } from '../components/FlowUI';
import { imageFor } from '../data/demoData';
export default function MaintenanceScreen({ selected, go, tasks, setTasks, onFindService }) {
  const [tab, setTab] = useState('Upcoming');
  const [adding, setAdding] = useState(false);
  const [title, setTitle] = useState('');
  const photos = { oil: require('../../assets/oil.png'), tires: require('../../assets/tire.png'), brakes: require('../../assets/brake.png') };
  const assetTasks = tasks.filter(t => t.assetId === selected.id);
  const visible = tab === 'Rules' ? assetTasks : assetTasks.filter(t => !!t.done === (tab === 'Completed'));
  return <>
    <Tap style={[f.row, { paddingVertical: 14 }]} onPress={() => go('Details')}><Image source={imageFor(selected)} style={{ width: 85, height: 65, borderRadius: 10 }} /><View><Text style={f.title}>{selected.name}</Text><Text style={f.caption}>{selected.id === 'car' ? '24,300 miles' : selected.place}</Text></View></Tap>
    <Tabs value={tab} onChange={setTab} items={['Upcoming', 'Completed', 'Rules'].map(value => ({ value, label: `${value} (${assetTasks.filter(t => value === 'Rules' || !!t.done === (value === 'Completed')).length})` }))} />
    {visible.map(task => <View key={task.id} style={[f.card, f.row, { padding: 12, minHeight: 135 }]}><Image source={photos[task.id] || imageFor(selected)} style={{ width: 74, height: 84, borderRadius: 12, alignSelf: 'flex-start' }} /><View style={f.flex}><Text style={f.title}>{task.title}</Text><Text style={f.caption}>{task.rule}</Text><Text style={f.pill}>{task.done ? 'Completed' : task.due}</Text>{tab !== 'Rules' && <View style={[f.row, { marginTop: 10 }]}><Tap onPress={() => setTasks(tasks.map(t => t.id === task.id ? { ...t, done: !t.done } : t))}><Text style={{ color: '#087cff', fontSize: 12 }}>{task.done ? 'Reopen' : 'Mark Done'}</Text></Tap>{!task.done && <Tap label={`Find service for ${task.title}`} onPress={() => onFindService(task.title)}><Text style={{ color: '#087cff', fontSize: 12 }}>Find service →</Text></Tap>}</View>}</View></View>)}
    {!visible.length && <Text style={f.empty}>No {tab.toLowerCase()} maintenance yet.</Text>}
    {adding && <View style={f.card}><Text style={f.title}>New maintenance</Text><TextInput accessibilityLabel="Maintenance title" style={f.input} placeholder="e.g. Replace air filter" value={title} onChangeText={setTitle} /><Button title="Save maintenance" disabled={!title.trim()} onPress={() => { setTasks([...tasks, { id: String(Date.now()), assetId: selected.id, title: title.trim(), due: 'Not scheduled', rule: 'Custom reminder', done: false }]); setAdding(false); setTitle(''); setTab('Upcoming'); }} /></View>}
    <Button title={adding ? 'Cancel' : 'Add Maintenance'} icon="add-circle-outline" onPress={() => setAdding(!adding)} />
  </>;
}
