import React, { useState } from 'react';
import { View, Text, Pressable, Modal, ScrollView, KeyboardAvoidingView, Platform, StyleSheet } from 'react-native';
import { AuthLayout, AuthButton, AuthField, useAuthStyles } from '../components/AuthUI';
import { Icon, Tap } from '../components/ui';
import { s } from '../theme/styles';

const choices = [
  { name: 'Home', description: 'Track maintenance, warranty, and value', icon: 'home-outline', color: '#087bff', background: '#e8f4ff', group: 'Home', image: require('../../assets/property-onboarding-house.png') },
  { name: 'Vehicle', description: 'Service, insurance, and important dates', icon: 'car-outline', color: '#00ad90', background: '#e5faf4', group: 'Vehicles', image: require('../../assets/premium-car.png') },
  { name: 'HVAC', description: 'Maintenance and service history', icon: 'snow-outline', color: '#9163e6', background: '#f2ecff', group: 'Home', image: require('../../assets/ac-new.png') },
  { name: 'Appliance', description: 'Track lifespan and repairs', icon: 'file-tray-stacked-outline', color: '#d76b85', background: '#fff0f3', group: 'Home', image: require('../../assets/fridge.png') },
  { name: 'Other Asset', description: 'Tools, furniture, electronics, and more', icon: 'clipboard-outline', color: '#e5a215', background: '#fff7e4', group: 'Other', image: require('../../assets/laptop.png') },
  { name: 'Add Later', description: 'You can add assets anytime from the app', icon: 'ellipsis-horizontal', color: '#7f93ab', background: '#eff2f6' },
];

export default function AssetOnboardingScreen({ go, workspace, onAdd, initialCategory }) {
  const a = useAuthStyles('create');
  const [selected, setSelected] = useState(choices.find(choice => choice.name === initialCategory) || null);
  const [adding, setAdding] = useState(!!initialCategory);
  const [name, setName] = useState('');
  const [model, setModel] = useState('');
  const [error, setError] = useState('');
  const [selectionError, setSelectionError] = useState('');
  const choose = choice => {
    if (choice.name === 'Add Later') { go('Home'); return; }
    setSelected(choice); setSelectionError(''); setAdding(true);
  };
  return <AuthLayout variant="create" onBack={() => go('PropertyOnboarding')} backLabel="Back to property step">
    <View style={[a.panel, { paddingHorizontal: 16 }]}>
      <Text accessibilityRole="header" style={[a.heading, { fontSize: 27 }]}>Add Your First Asset</Text>
      <Text style={a.description}>Start tracking your home, vehicles, appliances and more. You can always add more later.</Text>
      <View style={p.grid}>{choices.map(choice => <Pressable key={choice.name} accessibilityRole="button" accessibilityLabel={choice.name} onPress={() => choose(choice)} style={({ pressed }) => [p.card, selected?.name === choice.name && { borderColor: '#3488ff', backgroundColor: '#f5f9ff' }, pressed && { opacity: .7 }]}>
        <View style={[p.icon, { backgroundColor: choice.background }]}><Icon name={choice.icon} size={25} color={choice.color} /></View>
        <Text style={p.title}>{choice.name}</Text><Text style={p.description}>{choice.description}</Text>
      </Pressable>)}</View>
      {!!selectionError && <Text accessibilityRole="alert" style={a.error}>{selectionError}</Text>}
      <AuthButton title="Add Asset" onPress={() => { if (!selected) { setSelectionError('Choose an asset type above to get started.'); return; } setAdding(true); }} />
      <AuthButton title="Skip Asset" secondary onPress={() => go('Home')} />
    </View>
    <Modal visible={adding} transparent animationType="fade" onRequestClose={() => setAdding(false)}><KeyboardAvoidingView style={s.backdrop} behavior={Platform.OS === 'ios' ? 'padding' : undefined}><View style={[s.dialog, { maxHeight: '90%' }]}><ScrollView keyboardShouldPersistTaps="handled">
      <View style={p.formHeader}><Text style={[a.heading, { fontSize: 24, flex: 1 }]}>Add {selected?.name === 'Other Asset' ? 'Asset' : selected?.name}</Text><Tap label="Close asset form" onPress={() => setAdding(false)}><Icon name="close" /></Tap></View>
      <AuthField label="Asset Name" icon={selected?.icon || 'cube-outline'} value={name} onChangeText={value => { setName(value); setError(''); }} placeholder={selected?.name === 'Vehicle' ? 'e.g. Toyota Camry' : 'Enter asset name'} autoCapitalize="words" error={error} maxLength={100} />
      <AuthField label="Model or Details (Optional)" icon="document-text-outline" value={model} onChangeText={setModel} placeholder="Brand, model, or a short description" autoCapitalize="sentences" />
      <Text style={a.hint}>Added to {workspace?.name || 'your demo workspace'}. Saved for this session only.</Text>
      <AuthButton title="Save Asset" onPress={() => { if (!name.trim()) { setError('Enter an asset name.'); return; } onAdd({ name: name.trim(), model: model.trim() || selected.name, group: selected.group, category: selected.name, imageSource: selected.image }); }} />
    </ScrollView></View></KeyboardAvoidingView></Modal>
  </AuthLayout>;
}
const p = StyleSheet.create({
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 9, marginBottom: 5 },
  card: { flexBasis: '46%', flexGrow: 1, borderWidth: 1, borderColor: '#e5ebf3', backgroundColor: '#fff', borderRadius: 14, padding: 13, minHeight: 133 },
  icon: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center', marginBottom: 8 },
  title: { fontSize: 14, fontWeight: '600', color: '#0b2c46', marginBottom: 4 },
  description: { fontSize: 12, lineHeight: 17, color: '#7b91aa' },
  formHeader: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 18 },
});
