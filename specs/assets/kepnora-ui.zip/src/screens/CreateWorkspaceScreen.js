import React, { useState } from 'react';
import { View, Text, Pressable, StyleSheet, useWindowDimensions } from 'react-native';
import { Tap, Icon } from '../components/ui';
import { AuthLayout, AuthField, AuthButton, useAuthStyles } from '../components/AuthUI';

const types = [
  { name: 'Primary Home', description: 'Your main residence', icon: 'home-outline' },
  { name: 'Rental Property', description: 'Investment property', icon: 'business-outline' },
  { name: 'Vacation Home', description: 'Second home', icon: 'home-outline' },
  { name: 'Other', description: 'e.g. Land, Garage, Etc.', icon: 'leaf-outline' },
];

export default function CreateWorkspaceScreen({ go, onCreate, draft, setDraft }) {
  const a = useAuthStyles('create');
  const { width } = useWindowDimensions();
  const [error, setError] = useState('');
  const update = (key, value) => setDraft(previous => ({ ...previous, [key]: value }));
  const submit = () => {
    if (!draft.name.trim()) { setError('Enter a workspace name.'); return; }
    setError('');
    onCreate({ ...draft, name: draft.name.trim(), address: draft.address.trim() });
  };
  return <AuthLayout variant="create" onBack={() => go('CreateAccount')}>
    <View style={a.panel}>
      <Text accessibilityRole="header" style={[a.heading, { fontSize: width < 360 ? 25 : 28 }]}>Create Workspace</Text>
      <Text style={a.description}>Add a workspace to start managing your assets, maintenance, and documents.</Text>
      <AuthField label="Workspace Name" icon="home-outline" placeholder="e.g. My Home, Vacation Home, Rental Property" value={draft.name} onChangeText={value => { update('name', value); setError(''); }} autoCapitalize="words" maxLength={80} error={error} hint="You can create multiple workspaces later." />
      <Text style={[a.label, { marginTop: 15, marginBottom: 9 }]}>Property Type</Text>
      <View accessibilityRole="radiogroup" accessibilityLabel="Property Type" style={w.grid}>
        {types.map(type => {
          const selected = draft.type === type.name;
          return <Pressable key={type.name} accessibilityRole="radio" accessibilityLabel={type.name} accessibilityState={{ checked: selected }} aria-checked={selected} onPress={() => update('type', type.name)} style={({ pressed }) => [w.type, selected && w.selected, pressed && { opacity: .7 }]}>
            <View style={w.typeHeader}><Icon name={type.icon} color={selected ? '#0065ff' : '#66809c'} size={26} /><Icon name={selected ? 'checkmark-circle' : 'ellipse-outline'} size={21} color={selected ? '#0065ff' : '#a8b8cc'} /></View>
            <Text style={w.typeName}>{type.name}</Text><Text style={w.typeDescription}>{type.description}</Text>
          </Pressable>;
        })}
      </View>
      <AuthField label="Address (Optional)" icon="location-outline" placeholder="Enter property address" value={draft.address} onChangeText={value => update('address', value)} autoCapitalize="words" autoComplete="street-address" hint="Address helps with local weather, maintenance reminders, and value tracking." />
      <AuthButton title="Create Workspace" onPress={submit} />
    </View>
    <Tap style={[a.demo, { paddingVertical: 18 }]} onPress={() => go('Home')}><Text style={a.link}>Skip for now</Text></Tap>
    <Text style={[a.hint, { textAlign: 'center', marginHorizontal: 24, marginBottom: 12 }]}>Demo workspace · Saved for this session only</Text>
  </AuthLayout>;
}

const w = StyleSheet.create({
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 9, marginBottom: 18 },
  type: { flexBasis: '46%', flexGrow: 1, borderWidth: 1, borderColor: '#dfe7f1', borderRadius: 13, padding: 13, minHeight: 112, backgroundColor: '#fff' },
  selected: { borderColor: '#3488ff', backgroundColor: '#f0f7ff' },
  typeHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 },
  typeName: { fontSize: 13, color: '#0b2c46', fontWeight: '600', marginBottom: 4 },
  typeDescription: { fontSize: 11, color: '#7b91aa', lineHeight: 16 },
});
