import React, { useState, createContext, useContext } from 'react';
import { View, Text, Image, TextInput, ScrollView, KeyboardAvoidingView, Platform, StyleSheet, useWindowDimensions, Modal } from 'react-native';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { Icon, Tap } from './ui';
import { s } from '../theme/styles';

const AuthSize = createContext({ width: 390, height: 800, variant: 'signin' });
export const useAuthSize = () => useContext(AuthSize);
export function useAuthStyles(kind) {
  const { width } = useWindowDimensions();
  const { variant } = useAuthSize();
  const create = (kind || variant) === 'create';
  const narrow = width < 360;
  return { ...a,
    panel: [a.panel, { paddingHorizontal: narrow ? 18 : 23, paddingVertical: create ? 18 : 23, marginHorizontal: 14, marginTop: -20, borderRadius: 23, backgroundColor: '#ffffff', zIndex: 1 }],
    heading: [a.heading, { fontSize: narrow ? 27 : 30 }],
    description: [a.description, { fontSize: 15, lineHeight: 21, marginBottom: create ? 14 : 18 }],
    fieldGroup: [a.fieldGroup, { marginBottom: create ? 10 : 14 }],
    label: [a.label, { marginBottom: 6 }], field: [a.field, { minHeight: create ? 44 : 48, borderRadius: 12 }],
    input: [a.input, { paddingVertical: 10 }], button: [a.button, { minHeight: create ? 48 : 52, borderRadius: 13 }],
    divider: [a.divider, { marginVertical: create ? 12 : 16 }], social: [a.social, { minHeight: 46, marginBottom: 8, borderRadius: 13 }],
    footer: [a.footer, { marginTop: 14 }], demo: [a.demo, { paddingVertical: 10 }],
  };
}
export function AuthLayout({ children, onBack, welcome = false, variant = 'signin', backLabel = 'Back to welcome' }) {
  const { width, height } = useWindowDimensions();
  const [size, setSize] = useState({ width: Math.min(width, 430), height });
  // Preserve the reference's full-width artwork; let the form scroll instead of shrinking it.
  const heroHeight = size.width * 449 / 779;
  return <SafeAreaProvider><View style={s.canvas}><SafeAreaView style={[s.app, a.shell, width > 600 && s.desktop]}><StatusBar style="dark" /><KeyboardAvoidingView onLayout={({ nativeEvent: { layout } }) => setSize({ width: layout.width, height: layout.height })} style={{ flex: 1, minHeight: 0 }} behavior={Platform.OS === 'ios' ? 'padding' : Platform.OS === 'android' ? 'height' : undefined}><AuthSize.Provider value={{ ...size, variant }}><ScrollView automaticallyAdjustKeyboardInsets keyboardDismissMode="on-drag" keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false} contentContainerStyle={[a.scroll, { paddingBottom: 8 }]}>
    {!welcome && <><Tap label={backLabel} style={[a.back, { minHeight: 44, paddingVertical: 8 }]} onPress={onBack}><Icon name="chevron-back" size={26} color="#052c44" /></Tap><Image accessibilityLabel="Kepnora. Everything You Own, Well Cared For." source={require('../../assets/auth-header.png')} style={[a.headerImage, { height: heroHeight }]} resizeMode="contain" /></>}
    {children}
  </ScrollView></AuthSize.Provider></KeyboardAvoidingView></SafeAreaView></View></SafeAreaProvider>;
}
export function AuthField({ label, value, onChangeText, placeholder, icon, password, error, hint, ...props }) {
  const a = useAuthStyles();
  const [visible, setVisible] = useState(false);
  return <View style={a.fieldGroup}><Text style={a.label}>{label}</Text><View style={[a.field, error && { borderColor: '#d94c4c' }]}><Icon name={icon} color="#7b91a9" size={21} /><TextInput accessibilityLabel={label} value={value} onChangeText={onChangeText} placeholder={placeholder} placeholderTextColor="#8a9db2" style={a.input} secureTextEntry={password && !visible} autoCapitalize="none" autoCorrect={false} {...props} />{password && <Tap label={`${visible ? 'Hide' : 'Show'} ${label.toLowerCase()}`} onPress={() => setVisible(!visible)} style={{ padding: 4 }}><Icon name={visible ? 'eye-outline' : 'eye-off-outline'} size={21} color="#7b91a9" /></Tap>}</View>{error ? <Text accessibilityRole="alert" style={a.error}>{error}</Text> : hint ? <Text style={a.hint}>{hint}</Text> : null}</View>;
}
export function AuthButton({ title, onPress, secondary = false }) {
  const a = useAuthStyles();
  return <Tap label={title} onPress={onPress} style={[a.button, secondary && a.secondary]}><Text style={[a.buttonText, secondary && { color: '#0065ff' }]}>{title}</Text>{!secondary && <Icon name="arrow-forward" size={22} color="white" />}</Tap>;
}
export function SocialButtons({ onPress }) {
  const a = useAuthStyles();
  return <><View style={a.divider}><View style={a.line} /><Text style={a.muted}>OR</Text><View style={a.line} /></View>{['Apple', 'Google'].map(provider => <Tap key={provider} label={`Continue with ${provider}`} style={a.social} onPress={() => onPress(provider)}>{provider === 'Apple' ? <Icon name="logo-apple" size={25} color="#050505" /> : <Text style={{ color: '#4285f4', fontSize: 26, fontWeight: '800' }}>G</Text>}<Text style={a.socialText}>Continue with {provider}</Text></Tap>)}</>;
}
export function AuthNotice({ message, onClose }) {
  return <Modal visible={!!message} transparent animationType="fade" onRequestClose={onClose}><View style={s.backdrop}><View style={s.dialog}><Text style={a.heading}>{message?.title}</Text><Text style={[a.muted, { marginVertical: 15 }]}>{message?.body}</Text><AuthButton title="Got it" onPress={onClose} /></View></View></Modal>;
}
export const emailValid = value => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.trim());
export const a = StyleSheet.create({
  shell: { backgroundColor: '#eff9fc' }, scroll: { flexGrow: 1, paddingBottom: 24 },
  back: { alignSelf: 'flex-start', padding: 14, paddingBottom: 6, zIndex: 1 }, headerImage: { width: '100%', height: 225 },
  panel: { backgroundColor: '#fffffffa', marginHorizontal: 16, marginTop: -3, borderRadius: 25, padding: 22, borderWidth: 1, borderColor: '#e6edf4', boxShadow: '0px 8px 30px rgba(14,55,76,0.035)' },
  heading: { color: '#052c44', fontSize: 29, fontWeight: '800', letterSpacing: -.7 }, description: { color: '#7a90a9', fontSize: 15, lineHeight: 22, marginTop: 8, marginBottom: 20 },
  fieldGroup: { marginBottom: 14 }, label: { fontSize: 14, color: '#0b2c46', marginBottom: 7, fontWeight: '600' }, field: { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: '#f8fafc', borderWidth: 1, borderColor: '#e2e9f2', borderRadius: 14, paddingHorizontal: 12, minHeight: 49 },
  input: { flex: 1, color: '#12334b', fontSize: 14, paddingVertical: 12, minWidth: 0, ...(Platform.OS === 'web' ? { outlineStyle: 'none' } : {}) }, hint: { color: '#8a9db4', fontSize: 11, lineHeight: 16, marginTop: 6 }, error: { color: '#c43f3f', fontSize: 12, lineHeight: 17, marginTop: 5 },
  button: { backgroundColor: '#04334b', borderRadius: 14, minHeight: 54, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 17, marginTop: 8 }, buttonText: { color: '#fff', fontSize: 17, fontWeight: '600' }, secondary: { backgroundColor: '#fff', borderWidth: 1, borderColor: '#dbe4ef' },
  divider: { flexDirection: 'row', alignItems: 'center', gap: 13, marginVertical: 17 }, line: { flex: 1, height: 1, backgroundColor: '#e2e9f1' }, muted: { color: '#7b90a9', fontSize: 14, lineHeight: 21 },
  social: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 15, minHeight: 49, backgroundColor: '#fff', borderWidth: 1, borderColor: '#dfe6f0', borderRadius: 14, marginBottom: 10 }, socialText: { color: '#0b2c46', fontSize: 14, fontWeight: '600' },
  link: { color: '#0065ff', fontSize: 14, fontWeight: '600' }, footer: { flexDirection: 'row', justifyContent: 'center', flexWrap: 'wrap', gap: 4, marginTop: 15 }, demo: { alignSelf: 'center', paddingVertical: 16 },
  check: { width: 21, height: 21, backgroundColor: '#0065ff', borderRadius: 5, alignItems: 'center', justifyContent: 'center' }, success: { backgroundColor: '#e9f8f4', borderRadius: 12, padding: 12, marginTop: 12 },
});
