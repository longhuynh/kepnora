import React from 'react';
import { View, Text, Image } from 'react-native';
import { C } from '../theme/colors';
import { s } from '../theme/styles';
import { Icon, Tap } from './ui';
import { pics } from '../data/demoData';

export default function MaintenanceCard({ item: m, onPress }) {
  return <Tap style={s.maintenanceCard} onPress={onPress}><Image source={pics[m.image]} style={s.maintenanceImage} /><View style={s.flex}><Text style={s.cardTitle}>{m.title}</Text><Text style={[s.small, { color: m.urgent ? C.red : C.muted, marginTop: 5 }]}>{m.image !== 'car' ? '▢ ' : ''}{m.due}</Text><Text style={[s.small, { marginTop: 4 }]}>{m.place}</Text></View><Icon name="chevron-forward" size={19} color={C.muted} /></Tap>;
}
