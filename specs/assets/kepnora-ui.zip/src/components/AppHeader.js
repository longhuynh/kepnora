import React from 'react';
import { View, Text, Image } from 'react-native';
import { C } from '../theme/colors';
import { s } from '../theme/styles';
import { Icon, Tap } from './ui';

export default function AppHeader({ screen, selected, go, open, back }) {
  if (screen === 'Home') return null;
  const titles = { Properties: 'Properties', AddDocument: 'Documents', Assets: 'Assets', Details: 'Asset Details', Services: 'Find Services', Maintenance: 'Maintenance', Provider: 'Provider Details', BookService: 'Book Service', BookDate: 'Book Service', Documents: 'Documents', Settings: 'Settings' };
  return <View style={s.header}><Tap label="Go back" onPress={back}><Icon name="chevron-back" /></Tap><Text style={s.headerTitle}>{titles[screen] || screen}</Text>{screen === 'Assets' ? <Tap label="Add asset" onPress={() => open('add', 'Add an asset')}><Icon name="add" size={27} /></Tap> : screen === 'Details' ? <Tap label="Asset options" onPress={() => open('edit', 'Edit asset name', selected.name)}><Icon name="create-outline" size={21} /></Tap> : null}</View>;
}
