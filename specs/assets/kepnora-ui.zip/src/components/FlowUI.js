import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Tap, Icon } from './ui';
import { C } from '../theme/colors';
export function Tabs({ items, value, onChange }) {
  return <View style={f.tabs}>{items.map(item => { const label = typeof item === 'string' ? item : item.label; const key = typeof item === 'string' ? item : item.value; return <Tap key={key} onPress={() => onChange(key)} style={[f.tab, key === value && f.activeTab]}><Text style={[f.tabText, key === value && { color: C.blue, fontWeight: '700' }]}>{label}</Text></Tap>; })}</View>;
}
export function Button({ title, onPress, icon, disabled = false }) {
  return <Tap label={title} onPress={disabled ? undefined : onPress} style={[f.button, disabled && { opacity: .4 }]}>{icon && <Icon name={icon} color="white" size={18} />}<Text style={f.buttonText}>{title}</Text></Tap>;
}
export function Steps({ step }) {
  return <View style={f.steps}>{['Service', 'Date & Time', 'Confirm'].map((label, i) => <View key={label} style={f.step}><View style={[f.stepCircle, i <= step && { backgroundColor: C.blue }]}><Icon name="checkmark" color="white" size={17} /></View><Text style={[f.caption, i <= step && { color: C.navy }]}>{label}</Text></View>)}</View>;
}
export const f = StyleSheet.create({
  card: { backgroundColor: '#fff', borderWidth: 1, borderColor: '#eef1f6', borderRadius: 17, padding: 15, boxShadow: '0px 3px 12px rgba(25,45,70,0.025)', marginBottom: 10 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 12 }, flex: { flex: 1 },
  title: { color: C.navy, fontSize: 16, fontWeight: '700', marginBottom: 6 },
  text: { color: C.navy, fontSize: 13, lineHeight: 21 }, caption: { color: C.muted, fontSize: 11, lineHeight: 18 },
  tabs: { flexDirection: 'row', backgroundColor: '#f2f5f9', borderRadius: 12, marginVertical: 16 },
  tab: { flex: 1, paddingVertical: 12, alignItems: 'center', borderBottomWidth: 2, borderBottomColor: 'transparent' },
  activeTab: { borderBottomColor: C.blue }, tabText: { fontSize: 11, color: C.navy },
  button: { backgroundColor: '#087bff', borderRadius: 13, boxShadow: '0px 5px 12px rgba(8,123,255,0.12)', padding: 15, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 9, marginVertical: 10 },
  buttonText: { color: 'white', fontSize: 14, fontWeight: '600' },
  steps: { flexDirection: 'row', justifyContent: 'space-around', marginVertical: 18 }, step: { alignItems: 'center', gap: 7, flex: 1 },
  stepCircle: { width: 27, height: 27, borderRadius: 14, backgroundColor: '#cbd3dd', alignItems: 'center', justifyContent: 'center' },
  pill: { alignSelf: 'flex-start', backgroundColor: '#fff0e4', color: '#e87817', borderRadius: 8, paddingHorizontal: 7, paddingVertical: 3, fontSize: 11, marginVertical: 5 },
  iconBox: { width: 43, height: 43, borderRadius: 12, alignItems: 'center', justifyContent: 'center', backgroundColor: '#e8f2ff' },
  input: { backgroundColor: '#f4f7fb', borderWidth: 1, borderColor: '#dfe7f1', borderRadius: 10, padding: 13, color: C.navy, marginVertical: 10 },
  empty: { paddingVertical: 35, textAlign: 'center', color: C.muted },
});
