import React from 'react';
import { View, Text, Pressable, TextInput } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { C } from '../theme/colors';
import { s } from '../theme/styles';

export function Icon({ name, size = 22, color = C.navy }) { return <Ionicons name={name} size={size} color={color} />; }
export function Tap({ children, onPress, style, label }) { return <Pressable accessibilityRole="button" accessibilityLabel={label} onPress={onPress} style={({ pressed }) => [style, pressed && { opacity: .65 }]}>{children}</Pressable>; }
export function Badge({ due }) { return <View style={[s.badge, due && { backgroundColor: '#fff1d8' }]}><Icon name="checkmark-circle" size={12} color={due ? '#e99400' : '#009d71'} /><Text style={{ fontSize: 11, color: due ? '#bc7400' : '#007659' }}>{due ? 'Maintenance due' : 'Good condition'}</Text></View>; }
export function Section({ title, action = 'See all', onPress }) { return <View style={s.section}><Text style={s.sectionTitle}>{title}</Text><Tap onPress={onPress}><Text style={s.link}>{action}</Text></Tap></View>; }
export function Search({ value, onChangeText, placeholder }) { return <View style={s.search}><Icon name="search-outline" size={19} color={C.muted} /><TextInput accessibilityLabel={placeholder} style={s.searchInput} placeholder={placeholder} placeholderTextColor={C.muted} value={value} onChangeText={onChangeText} /></View>; }

