import React from 'react';
import { View, Text, Image } from 'react-native';
import { C } from '../theme/colors';
import { s } from '../theme/styles';
import { Icon, Tap } from './ui';

export default function BottomNavigation({ screen, open, go }) {
  if (['Details', 'Services', 'Provider', 'BookService', 'BookDate'].includes(screen)) return null;
  if (['Home', 'Properties', 'Assets', 'Documents', 'AddDocument'].includes(screen)) return <View style={[s.bottomNav, { paddingVertical: 13 }]}>{[['Home', 'home'], ['Properties', 'business-outline'], ['Assets', 'car-outline'], ['Documents', 'document-text-outline']].map(([name, icon]) => <Tap key={name} label={name} style={s.navItem} onPress={() => go(name)}><Icon name={icon} size={24} color={screen === name || (screen === 'AddDocument' && name === 'Documents') ? '#06334f' : '#8295b1'} /><Text style={[s.navText, { fontSize: 11, color: screen === name ? '#06334f' : '#8295b1' }]}>{name}</Text></Tap>)}</View>;
  const items = [['Home', 'home-outline'], ['Assets', 'briefcase-outline'], ['Maintenance', 'build-outline'], ['Documents', 'document-text-outline'], ['More', 'ellipsis-horizontal']];
  return <View style={s.bottomNav}>{items.map(([name, icon]) => <Tap key={name} label={name} style={name === 'Add' ? s.addButton : s.navItem} onPress={() => name === 'Add' ? open('add', 'Add an asset') : go(name === 'More' ? 'Settings' : name)}><Icon name={icon} size={name === 'Add' ? 34 : 22} color={name === 'Add' ? 'white' : screen === name || (screen === 'Settings' && name === 'More') ? C.blue : '#6587b4'} />{name !== 'Add' && <Text style={[s.navText, screen === name && { color: C.blue }]}>{name}</Text>}</Tap>)}</View>;
}
