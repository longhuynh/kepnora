export const C = { navy: '#111827', blue: '#087bff', teal: '#00af98', muted: '#64748b', pale: '#f0f6fc', line: '#eaf0f7', red: '#ff443d' };
