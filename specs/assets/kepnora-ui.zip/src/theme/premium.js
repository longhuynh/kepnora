import { StyleSheet } from 'react-native';
export const premium = StyleSheet.create({
  family: { flexDirection: 'row', alignItems: 'center', gap: 12, padding: 13, backgroundColor: '#fff', borderRadius: 15, borderWidth: 1, borderColor: '#edf0f4', marginBottom: 12 },
  iconTile: { width: 38, height: 38, borderRadius: 11, alignItems: 'center', justifyContent: 'center', backgroundColor: '#e5f5ee' },
  hero: { borderRadius: 18, overflow: 'hidden', backgroundColor: '#173d47', marginBottom: 14 },
  heroImage: { width: '100%', height: 110 },
  heroSearch: { backgroundColor: '#ffffffed', borderRadius: 22, padding: 11, flexDirection: 'row', gap: 8, alignItems: 'center', margin: 12, marginTop: 0 },
  stat: { flex: 1, backgroundColor: '#fff', borderWidth: 1, borderColor: '#edf0f4', borderRadius: 15, padding: 14, gap: 5 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  title: { color: '#101827', fontSize: 14, fontWeight: '700', letterSpacing: -.3 },
  caption: { color: '#66748b', fontSize: 11, lineHeight: 17 },
  action: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 7, paddingVertical: 13, borderRadius: 14, backgroundColor: '#f0f4f9' },
  actionText: { color: '#074b9f', fontSize: 10 },
  badge: { borderRadius: 9, fontSize: 10, paddingHorizontal: 6, paddingVertical: 3, overflow: 'hidden', color: '#f47512', backgroundColor: '#fff1df' },
});
