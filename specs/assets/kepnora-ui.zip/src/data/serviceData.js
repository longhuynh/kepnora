export const shopImage = require('../../assets/premium-shop.png');
export const camryImage = require('../../assets/premium-car.png');
export const autoProviders = [
  { name: 'Cypress Auto Service', rating: '4.8', reviews: 231, distance: '2.3', imageSource: shopImage, tags: ['Oil Change', 'Tire Service', 'Brake Service'], price: 49.99, address: '12345 Cypress Creek Pkwy', open: true },
  { name: 'Quick Lube & Repair', rating: '4.6', reviews: 148, distance: '4.1', imageSource: shopImage, tags: ['Oil Change', 'Tire Service', 'Brake Service'], price: 39.99, address: '12400 Spring Cypress Rd', open: true },
  { name: 'Toyota of Cypress', rating: '4.4', reviews: 220, distance: '5.8', imageSource: camryImage, tags: ['Oil Change', 'Inspection'], price: 59.99, address: '20100 Northwest Fwy', open: true },
];
export const serviceOptions = [
  { name: 'Oil Change', price: 49.99 }, { name: 'Tire Rotation', price: 29.99 },
  { name: 'Brake Inspection', price: 79.99 }, { name: 'Multi-Point Inspection', price: 39.99 },
];
export const initialDocuments = [
  { id: 'engine', title: 'Photo - Engine', asset: 'Toyota Camry 2022', type: 'Photos', kind: 'Photo', date: 'Mar 1, 2025', size: '890 KB', image: require('../../assets/engine.png'), description: 'Engine inspection reference photo.' },
  { id: 'receipt', title: 'Oil Change Receipt', asset: 'Toyota Camry 2022', type: 'Receipts', kind: 'Receipt', date: 'Mar 1, 2025', size: '245 KB', image: require('../../assets/receipt.png'), description: 'Oil and filter replacement. Service total: $49.99. Sample receipt record.' },
  { id: 'manual', title: 'AC Manual', asset: 'Home AC Unit', type: 'Manuals', kind: 'Manual', date: 'Jan 15, 2025', size: '2.1 MB', icon: 'document-text', description: 'Carrier Infinity 24VNA6. Replace the air filter every 3 months. Sample manual record.' },
  { id: 'warranty', title: 'Refrigerator Warranty', asset: 'Refrigerator', type: 'Manuals', kind: 'Warranty', date: 'Oct 3, 2024', size: '1.4 MB', icon: 'document', description: 'LG LTCS24223S warranty information. Sample warranty record.' },
  { id: 'insurance', title: 'Car Insurance', asset: 'Toyota Camry 2022', type: 'Photos', kind: 'Insurance', date: 'Jan 10, 2024', size: '1.2 MB', image: require('../../assets/insurance.png'), description: 'Vehicle insurance reference. Sample document record.' },
];
