export const pics = { mower: require('../../assets/mower.png'), logo: require('../../assets/logo.png'), avatar: require('../../assets/avatar.png'), ac: require('../../assets/ac-new.png'), water: require('../../assets/water.png'), fridge: require('../../assets/fridge.png'), washer: require('../../assets/washer.png'), car: require('../../assets/premium-car.png'), laptop: require('../../assets/laptop.png'), hero: require('../../assets/hero.png'), pro1: require('../../assets/pro1.png'), pro2: require('../../assets/pro2.png'), pro3: require('../../assets/pro3.png') };
export const initialAssets = [
  { id: 'home-property', name: 'My Home', model: 'Primary Home', place: '10615 Thistle Flower Dr\nCypress, TX 77433', group: 'Home', category: 'Property', brand: '—', imageSource: require('../../assets/dashboard-property.png') },
  { id: 'ac', name: 'Home AC Unit', model: 'Carrier Infinity 24VNA6', place: 'Home • Backyard', group: 'Home', category: 'HVAC', brand: 'Carrier' },
  { id: 'water', name: 'Water Heater', model: 'Rheem 50 Gallon', place: 'Home • Garage', group: 'Home', category: 'Plumbing', brand: 'Rheem' },
  { id: 'fridge', name: 'Refrigerator', model: 'LG LTCS24223S', place: 'Home • Kitchen', group: 'Home', due: true, category: 'Appliance', brand: 'LG' },
  { id: 'washer', name: 'Washer', model: 'Samsung WF45T6000', place: 'Home • Laundry', group: 'Home', category: 'Appliance', brand: 'Samsung' },
  { id: 'car', name: 'Toyota Camry 2022', model: 'Toyota Camry', place: 'Vehicle', group: 'Vehicles', category: 'Vehicle', brand: 'Toyota' },
  { id: 'mower', name: 'Lawn Mower', model: 'Equipment', place: 'Equipment • Outdoor', group: 'Other', category: 'Equipment', brand: 'Honda' },
  { id: 'laptop', name: 'MacBook Pro', model: 'Apple MacBook Pro 14”', place: 'Personal', group: 'Other', category: 'Electronics', brand: 'Apple' },
];
export const providers = [ { name: 'Summit HVAC', rating: '4.9', reviews: 128, distance: '2.1', image: 'pro1', tags: ['HVAC', 'AC Repair', 'Installation'] }, { name: 'AirTech Solutions', rating: '4.8', reviews: 95, distance: '3.4', image: 'pro2', tags: ['HVAC', 'Maintenance', 'Duct Cleaning'] }, { name: 'Cool Comfort Pros', rating: '4.7', reviews: 86, distance: '5.1', image: 'pro3', tags: ['AC Repair', 'Heating', 'Installation'] } ];

export const imageFor = (asset) => asset.imageSource || pics[asset.id] || pics.laptop;
